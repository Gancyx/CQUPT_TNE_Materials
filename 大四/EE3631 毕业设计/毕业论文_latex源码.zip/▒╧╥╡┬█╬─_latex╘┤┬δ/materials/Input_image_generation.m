% 创建一个 4x10 的随机图像，每个像素的值为0或255
original_image = randi([0, 1], 4, 10) * 255;

expanded_image = imresize(original_image, 50, 'nearest');

% 显示扩大后的图像
imshow(expanded_image, []);
% title('Expanded 16x40 Image');

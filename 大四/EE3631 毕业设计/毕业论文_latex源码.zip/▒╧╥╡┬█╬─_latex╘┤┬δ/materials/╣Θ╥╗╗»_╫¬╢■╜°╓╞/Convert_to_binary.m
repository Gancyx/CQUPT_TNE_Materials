clc;
clear;

%% 数据归一化并映射到整数范围
% 读取MAT文件
dataStruct = load('data.mat');
% 获取数据
data = dataStruct.data;
% 定义二进制表示的位数为m
m = 10;

% 检查数据的列数
[rows, cols] = size(data);
disp(['数据有 ', num2str(rows), ' 行和 ', num2str(cols), ' 列']);

% 对每列进行归一化并映射到 [0, 2^m - 1]，并取整数
mappedData = zeros(size(data));
for col = 1:cols
    % 检查数据是否为标签列
    if cols >= 5 && col == 5
        % 如果是第五列且数据有5列或更多，则保持原样
        mappedData(:, col) = data(:, col);
    else
        % 其他列进行归一化处理
        minVal = min(data(:, col));
        maxVal = max(data(:, col));
        % 归一化并映射到 [0, 2^m - 1]，然后四舍五入取整
        mappedData(:, col) = round(((data(:, col) - minVal) / (maxVal - minVal)) * (2^m - 1));
    end
end

% 打印映射后的整数数据
disp('映射后的数据:');
disp(mappedData);

% 保存映射数据到新的 MAT 文件
save('mapped_data.mat', 'mappedData');

%% 将数据映射转换为二进制并保存为CSV文件
% 确定要处理的列数（排除标签列）
process_cols = min(cols, 4); % 只处理前4列，如果数据不足4列则处理全部

% 初始化存储二进制字符串的矩阵
binary_strings = cell(rows, process_cols);

% 将数据转换为10位二进制字符串
for i = 1:rows
    for j = 1:process_cols
        binary_strings{i, j} = dec2bin(mappedData(i, j), m);
    end
end

% 定义特定的列名
column_names = {'L (mm)_Binary', 'W (mm)_Binary', 'h (mm)_Binary', 'eps_r_Binary'};

% 根据实际数据列数调整列名
actual_column_names = column_names(1:process_cols);

% 创建包含二进制表示的表格
binary_table = cell2table(binary_strings, 'VariableNames', actual_column_names);

% 如果有标签列（第5列），则添加到表格
if cols >= 5
    binary_table.Label = mappedData(:, 5);
end

% 保存为CSV文件
writetable(binary_table, 'binary_data.csv');

disp('归一化和二进制转换完成，结果已保存为 binary_data.csv');